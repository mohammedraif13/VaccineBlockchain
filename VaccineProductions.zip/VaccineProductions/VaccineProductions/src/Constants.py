serverName = "WISEN"
databaseName = "VaccineProductionsV1"
connString = "Driver={SQL Server};Server="+serverName+";Integrated_Security=true;Database="+databaseName
contract_address = "0xe40E0c6D216d1529a7B5AcEa704CCEeD1147153F"
inspection_contract_address = "0x2aAb6C19B1E6E84E5aD9966901EC0Ad3Dee99f35"
inspection_in_charge_contract = '0xAF63177d6999828C0E9E3Db698D360115aB616D8'
inspection_reviewer_contract = '0x06344f99539324673928f13199aF870804CD8961'
packing_contract_address = "0x2782E956D0278501A6b3bf1FC92635A7a7C93a00"
packing_in_charge_contract = '0x584f22886a74da782ad45D1170bDFe42Ddb69311'
packing_reviewer_contract = '0x65D571dbd0C64e9a9FEce79eAD11eddF8C7F8B49'
production_contract_address = "0x97215D6F185F35D3Ce85a2FE8ebEf9eAB81fA759"
production_in_charge_contract="0x722575ba51BFe978C05721b09f0Ea6398B2674A4"
production_reviewer_contract="0xD21F91F027D012Bd1C0E32D54F3842c33e39FC8F"
role_contract_address = "0xBe4F22f0784296032F24476270890D304f29DA9F"
users_contract_address = "0x2f51e26C51887e6235D1B427Fd2F3Ad05E275085"
