const Production = artifacts.require("ProductionContract.sol");
        module.exports = function (deployer) {
          deployer.deploy(Production);
        };
        